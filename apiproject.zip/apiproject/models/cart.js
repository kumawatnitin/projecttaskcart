const mongoose=require('mongoose')


const cartschema=mongoose.Schema({
    name:String,
    qty:Number,
    price:Number,
    username:String,
    status:{type:String,default:'IN-PROCESS'}
})

module.exports=mongoose.model('cart',cartschema)