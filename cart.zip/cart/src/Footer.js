import { useState } from "react";

function Footer() {
    
    return ( 
        <section id="footer">
        <div className="container">
            <div className="row">
                <div className="col-md-12">Footer</div>
            </div>
        </div>
        </section>
     );
}

export default Footer;