import { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Contextapi } from "./Contextapi";

function Login() {
    const{setLoginname}=useContext(Contextapi)
    let navigate=useNavigate()
    const[username,setUsername]=useState('')
    const[password,setPassword]=useState('')
    const[message,setMessage]=useState('')
    const[login,setLogin]=useState('')


    function handleform(e){
        e.preventDefault()
        const formdata={username,password}
        fetch('/api/logincheck',{
            method:'POST',
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(formdata)
        }).then((result)=>{return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status===200 && data.username==='admin'){
                localStorage.setItem('loginname',data.username)
                setLoginname(localStorage.getItem('loginname'))
                navigate('/dasboard')
            }else if(data.status===200 && data.username!='admin'){
                localStorage.setItem('loginname',data.username)
                setLoginname(localStorage.getItem('loginname'))
                navigate('/products')
            }else{
                setMessage(data.message)
            }
        })
    }
    return ( 
        <section id="login">
            <div className="container">
                <div className="row">
                    <div className="col-md-4"></div>
                    <div className="col-md-4">
                        <h2>Login Here!!</h2>
                        <p>{message}</p>
                        <form onSubmit={(e)=>{handleform(e)}}>
                            <label>Username</label>
                            <input type="text"  
                            value={username}
                            onChange={(e)=>{setUsername(e.target.value)}}
                            className="form-control"/>
                            <label>Password</label>
                            <input type="text" 
                            value={password}
                            onChange={(e)=>{setPassword(e.target.value)}}
                            className="form-control" />
                            <button type="submit" className="form-control btn btn-success mt-2">Login</button>
                        </form>
                        <p>
                            <Link to='/reg'>Registration</Link>
                        </p>
                    </div>
                    <div className="col-md-4"></div>

                </div>
            </div>
        </section>
     );
}

export default Login;