import Left from "./Left";

function Admindashboard() {
    return ( 
        <>
       
        <section id="mid">
        <div className="container">
            <div className="row">
                <Left/>
                <div className="col-md-9">MID</div>
            </div>
        </div>
        </section>
        
        </>
     );
}

export default Admindashboard;