import { useContext, useEffect, useState } from "react";
import { Contextapi } from "./Contextapi";
import { useNavigate } from "react-router-dom";

function Cart() {
    let navigate=useNavigate()
    const [cartdata, setCartData] = useState([])
    const [isLoading, setIsloading] = useState(true)

    const { cart, setCart } = useContext(Contextapi)
    useEffect(() => {
        if(!cart.items){
            return
        }
        fetch('/api/cart', {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ ids: Object.keys(cart.items) })
        }).then((resp) => { return resp.json() }).then((data) => {
            //console.log(data)
            if (data.status === 200) {
                setCartData(data.apiData)
                setIsloading(false)
            } else {
                console.log(data.message)
            }
        })
    }, [cart])
    let amount=0
    function handleqty(id){
       return cart.items[id]
    }
    function handleprice(id,price){
      let productprice=  handleqty(id)*price
      amount +=productprice
      return productprice
    }
    function hanldeincr(e,id,qty){
        let currentqty=handleqty(id)
        if(currentqty===qty){
            alert('you have reached to MAX quantity')
            return
        }
        let _cart={...cart}
        _cart.items[id]=currentqty+1
        _cart.totalItems +=1
        setCart(_cart)
    }

    function handledec(e,id){
        let currentqty=handleqty(id)
        if(currentqty===1){
            return
        }
        let _cart={...cart}
        _cart.items[id]=currentqty-1
        _cart.totalItems -=1
        setCart(_cart)
    }
    function handledelete(e,id){
            let currentqty=handleqty(id)
            let _cart={...cart}
            delete _cart.items[id]
            _cart.totalItems -=currentqty
            setCart(_cart)
            
    }
    function handlecheckout(e){
        let username=localStorage.getItem('loginname')
        fetch(`/api/cartvalue/${username}`,{
            method:'POST',
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(cart)
        }).then((resp)=>{return resp.json()}).then((data)=>{
            //console.log(data)
            if(data.status===201){
                alert("Your orders has been successfully placed")
                setCart('')
               navigate('/products')

            }else{
                console.log(data.message)
            }
        })
    }
    return (
        <>
        {cartdata.length ?
        <section id="cart">
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        {isLoading && <h2>Data is loading</h2>}
                        <table className="table table-hover">
                            <thead>
                                <tr>
                                    <th>S.NO</th>
                                    <th>Product Name</th>
                                    <th>Product Quantity</th>
                                    <th>Product Price</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {cartdata.map((result,tt) => (
                                    <tr key={result._id}>
                                        <td>{tt+1}</td>
                                        <td>{result.name}</td>
                                        <td><button onClick={(e)=>{hanldeincr(e,result._id,result.quantity)}}>+</button>{handleqty(result._id)}<button onClick={(e)=>{handledec(e,result._id)}}>-</button></td>
                                        <td>{handleprice(result._id,result.price)}</td>
                                        <td><button onClick={(e)=>{handledelete(e,result._id)}}>Delete</button></td>
                                    </tr>
                                ))}

                                <tr>
                                    <td colSpan="5"><h4>Total Amount:{amount}</h4></td>
                                </tr>
                                <tr>
                                    <td colSpan="5"><button className="btn btn-primary form-control" onClick={(e)=>{handlecheckout(e)}}>Check Out</button></td>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
        :
        <img style={{width:'100%',height:'400px'}} src="/emptycart.jpeg" alt="" />
                                }
                                </>


    );
}

export default Cart;