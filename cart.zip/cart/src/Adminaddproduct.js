import { useState } from "react";
import Left from "./Left";

function Adminaddproduct() {
    const[name,setName]=useState('')
    const[desc,setDesc]=useState('')
    const[mdesc,setMdesc]=useState('')
    const[price,setPrice]=useState('')
    const[qty,setQty]=useState('')
    const[img,setImg]=useState('')
    const[message,setMessage]=useState('')

    function handleform(e){
        e.preventDefault()
        //console.log(name,desc,mdesc,price,qty)
        console.log(img)
        let data=new FormData()
        data.append('name',name)
        data.append('desc',desc)
        data.append('mdesc',mdesc)
        data.append('price',price)
        data.append('qty',qty)
        data.append('img',img)
        fetch('/api/addproduct',{
            method:'POST',
            body:data
        }).then((resp)=>{return resp.json()}).then((data)=>{
            //console.log(data)
            if(data.status===201){
                setMessage(data.message)
            }else{
                setMessage(data.message)
            }
        })
    }
    return ( 
        <>
        <section id="mid">
        <div className="container">
            <div className="row">
                <Left/>
                <div className="col-md-9">
                    <h2>Add Product Here</h2>
                    <p>{message}</p>
                    <form onSubmit={(e)=>{handleform(e)}}>
                    <label>Product Name</label>
                    <input type="text"
                    value={name}
                    onChange={(e)=>{setName(e.target.value)}}
                    className="form-control" />
                    <label>Description</label>
                    <textarea  className="form-control"
                     value={desc}
                     onChange={(e)=>{setDesc(e.target.value)}}
                    ></textarea>
                    <label> More Description</label>
                    <textarea  
                     value={mdesc}
                     onChange={(e)=>{setMdesc(e.target.value)}}
                    className="form-control"></textarea>
                    <label>Price</label>
                    <input type="number"
                     value={price}
                     onChange={(e)=>{setPrice(e.target.value)}}
                    className="form-control" />
                    <label>quantity</label>
                    <input type="number"  
                     value={qty}
                     onChange={(e)=>{setQty(e.target.value)}}
                    className="form-control" />
                    <label>Product Image</label>
                    <input type="file" 
                    onChange={(e)=>{setImg(e.target.files[0])}}
                    className="form-control" />
                    <button type="submit"  className="form-control btn btn-success mt-2 mb-2">ADD</button>
                    </form>
                </div>
            </div>
        </div>
        </section>
        
        </>
     );
}

export default Adminaddproduct;