import { Link } from "react-router-dom";
import Left from "./Left";
import { useEffect, useState } from "react";

function Adminproducts() {
    const [productdata, setProductdata] = useState([])
    useEffect(() => {
        fetch('/api/allproductdata').then((resp) => { return resp.json() }).then((data) => {
            //console.log(data)
            if (data.status === 200) {
                setProductdata(data.apiData)
            } else {
                console.log(data.message)
            }
        })
    }, [])
    return (
        <>

            <section id="mid">
                <div className="container">
                    <div className="row">
                        <Left />
                        <div className="col-md-9">
                            <h2>Product Management</h2>
                            <Link to='/addproduct'><button className="btn btn-info form-control">Add New Products</button></Link>
                            <table className="table table-hover">
                                <thead>
                                    <tr>
                                        <th>S.NO</th>
                                        <th>Product Name</th>
                                        <th>Product Description</th>
                                        <th>Product Price</th>
                                        <th>Product More Description</th>
                                        <th>Product Quantity</th>
                                        <th>CReated Date</th>
                                        <th>Image</th>
                                        <th>Product Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {productdata.map((result, hh) => (
                                        <tr key={result._id}>
                                            <td>{hh+1}</td>
                                            <td>{result.name}</td>
                                            <td>{result.desc}</td>
                                            <td>{result.price}</td>
                                            <td>{result.mdesc}</td>
                                            <td>{result.quantity}</td>
                                            <td>{result.createdDate}</td>
                                            <td><img style={{width:'50px'}} src={result.img} /></td>
                                            <td>{result.status}</td>
                                            <td><Link to={`/productupdate/${result._id}`}><button>Update</button></Link></td>
                                        </tr>
                                    ))}

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>

        </>
    );
}

export default Adminproducts;