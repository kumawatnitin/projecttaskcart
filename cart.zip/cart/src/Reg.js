import { useState } from 'react';
import { Link } from 'react-router-dom'
function Reg() {
    const[username,setUsername]=useState('')
    const[password,setPassword]=useState('')
    const[message,setMessage]=useState('')

    function handleform(e){
        e.preventDefault()
        const data={username,password}
        fetch('/api/reg',{
            method:'POST',
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(data)
        }).then((result)=>{return result.json()}).then((data)=>{
            console.log(data)
            if(data.status===201){
                setMessage(data.message)
            }else{
                setMessage(data.message)

            }
        })
    }
    return ( 
        <section id="login">
        <div className="container">
            <div className="row">
                <div className="col-md-4"></div>
                <div className="col-md-4">
                    <h2>Registration Here!!</h2>
                    <p>{message}</p>
                    <form onSubmit={(e)=>{handleform(e)}}>
                        <label>Username</label>
                        <input type="text"  
                        className="form-control"
                        value={username}
                        onChange={(e)=>{setUsername(e.target.value)}}
                        />
                        <label>Password</label>
                        <input type="text" 
                        
                        className="form-control"
                        value={password}
                        onChange={(e)=>{setPassword(e.target.value)}}
                        />
                        <button type="submit" className="form-control btn btn-success mt-2">Login</button>
                    </form>
                    <p>
                        <Link to='/'>You already have account?Click here</Link>
                    </p>
                </div>
                <div className="col-md-4"></div>

            </div>
        </div>
    </section>
     );
}

export default Reg;