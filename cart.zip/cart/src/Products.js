import { useEffect, useState } from "react";
import Productstr from "./Productstr";

function Products() {
    const[productdata,setProductdata]=useState([])
    useEffect(()=>{
        fetch('/api/stockdata').then((resp)=>{return resp.json()}).then((data)=>{
            //console.log(data)
            if(data.status===200){
                setProductdata(data.apiData)
            }else{
                console.log(data.message)
            }
        })
    },[])
    return ( 
        <section>
            <div className='container'>
                <div className='row'>
        {productdata.map((result,tt)=>(
            <Productstr pdata={result} />
        ))}
        </div>
            </div>
        </section>
       

     );
}

export default Products;