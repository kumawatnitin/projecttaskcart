import { BrowserRouter as Router,Route,Routes } from 'react-router-dom'
import { useEffect } from 'react'
import Login from './Login';
import Reg from './Reg';
import Products from './Products';
import Admindashboard from './Admindashboard';
import Header from './Header';
import Footer from './Footer';
import { Contextapi } from './Contextapi';
import { useState } from 'react';
import Adminproducts from './Adminproducts';
import Adminaddproduct from './Adminaddproduct';
import Adminproductupdate from './Adminproductupdate';
import Cart from './Cart';
import Myorders from './Myorders';
function App() {
  const[loginname,setLoginname]=useState(localStorage.getItem('loginname'))
  const[cart,setCart]=useState(JSON.parse((localStorage.getItem('cart'))))
  useEffect(()=>{
    localStorage.setItem('cart',JSON.stringify(cart))
  },[cart])
  return (
    <Router>
      <Contextapi.Provider value={{loginname,setLoginname,cart,setCart}}>
      <Header/>
      <Routes>
        <Route path='/' element={<Login/>} ></Route>
        <Route path='/reg' element={<Reg/>} ></Route>
        <Route path='/products' element={<Products/>} ></Route>
        <Route path='/dasboard' element={<Admindashboard/>} ></Route>
        <Route path='/adminproducts' element={<Adminproducts/>} ></Route>
        <Route path='/addproduct' element={<Adminaddproduct/>} ></Route>
        <Route path='/productupdate/:id' element={<Adminproductupdate/>} ></Route>
        <Route path='/cart' element={<Cart/>} ></Route>
        <Route path='/myorders' element={<Myorders/>} ></Route>

      </Routes>
      <Footer/>
      </Contextapi.Provider>
    </Router>
    );
}

export default App;